"""Build original figures and machine-derived Markdown tables for the post."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from experiments import LOW, HIGH, N, make_dataset, quantize, pixel_plot

ROOT = Path(__file__).parent
FIG = ROOT / 'assets'
FIG.mkdir(exist_ok=True)
R = json.loads((ROOT/'results/results.json').read_text())
BLUE, ORANGE, GRAY = '#176b9a', '#ce612d', '#6f7d89'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,
    'axes.spines.top':False,'axes.spines.right':False,'axes.titlesize':12,
    'axes.labelsize':10.5,'legend.fontsize':9,'figure.facecolor':'white',
    'axes.facecolor':'white','savefig.facecolor':'white','svg.fonttype':'none',
    'axes.grid':False,'figure.constrained_layout.use':True})


def save(fig, name):
    with plt.rc_context({'svg.hashsalt':name}):
        fig.savefig(FIG/f'{name}.svg',bbox_inches='tight')
        fig.savefig(FIG/f'{name}.png',dpi=180,bbox_inches='tight')
    plt.close(fig)


fig,axs=plt.subplots(2,2,figsize=(10.7,6),width_ratios=(1.1,1))
for i,task in enumerate(['oscillations','transients']):
    x,y=make_dataset(task,8,8080+i)
    q,c=quantize(x,32)
    idx=np.where(y==1)[0][0]
    axs[i,0].plot(np.arange(N)/N,x[idx],color=GRAY,lw=1.1,alpha=.65,label='Before quantization')
    axs[i,0].step(np.arange(N)/N,q[idx],where='mid',color=BLUE,lw=1.3,label='Numerical CNN input')
    axs[i,0].set(title=task.capitalize(),xlabel='Time / observation window',ylabel='Amplitude')
    image=pixel_plot(c[[idx]],32)[0,0]
    axs[i,1].imshow(image,origin='lower',aspect='auto',cmap='Greys',interpolation='nearest',
                    extent=(0,1,LOW,HIGH),vmin=0,vmax=1)
    axs[i,1].set(title='Reversible 32 × 128 pixel plot',xlabel='Time / observation window',
                 ylabel='Amplitude cell')
handles,labels=axs[0,0].get_legend_handles_labels()
fig.legend(handles,labels,loc='outside lower center',ncol=2,frameon=False)
save(fig,'01_representations')

height=32
step=(HIGH-LOW)/height
center=LOW+(height//2+.5)*step
raw=np.array([np.full(N,center-step/10),np.full(N,center+step/10)],np.float32)
q,c=quantize(raw,height)
fig,axs=plt.subplots(1,3,figsize=(11.5,3.25),width_ratios=(1.2,1,1))
axs[0].axhspan(center-step/2,center+step/2,color=BLUE,alpha=.10,label='One quantization cell')
for i,color in enumerate([BLUE,ORANGE]):
    axs[0].plot(np.arange(N)/N,raw[i],color=color,lw=2,label=f'Class {i}')
axs[0].axhline(center,color=GRAY,ls='--',lw=1,label='Raw decision threshold')
axs[0].set(ylim=(center-step*.6,center+step*.6),xlabel='Time / window',
           ylabel='Amplitude',title='Two distinguishable numerical curves')
axs[0].legend(frameon=False,loc='upper right',fontsize=8)
for i,ax in enumerate(axs[1:]):
    im=ax.imshow(pixel_plot(c,height)[i,0],origin='lower',aspect='auto',cmap='Greys',
              extent=(0,1,LOW,HIGH),interpolation='nearest',vmin=0,vmax=1)
    im.set_gid(f'collision_class_{i}')
    ax.set(title=f'Class {i}: same pixel plot',xlabel='Time / window',ylabel='Amplitude cell')
save(fig,'02_quantization_collision')

bench=sorted(R['benchmarks'],key=lambda b:(b['model'],b['height'] or 0))
baseline=next(b for b in bench if b['model']=='1d')
images=[b for b in bench if b['model']=='2d']
heights=np.array([b['height'] for b in images])
fig,axs=plt.subplots(1,3,figsize=(11.5,3.5))
axs[0].plot(heights,[b['description']['conv_macs']/1e6 for b in images],'-o',color=ORANGE,label='2D CNN')
axs[0].axhline(baseline['description']['conv_macs']/1e6,color=BLUE,ls='--',label='1D CNN')
axs[0].set(ylabel='Convolutional MACs / series (millions)',title='Arithmetic count')
for ax,key,title in [(axs[1],'batch1','Batch size 1'),(axs[2],'batch64','Batch size 64: amortized')]:
    factor=1 if key=='batch1' else 64
    med=np.array([b[key]['median_ms']/factor for b in images])
    ax.plot(heights,med,'-o',color=ORANGE,label='2D CNN')
    ax.axhline(baseline[key]['median_ms']/factor,color=BLUE,ls='--',label='1D CNN')
    ax.set(ylabel='Median milliseconds / series',title=title)
for ax in axs:
    ax.set(xlabel='Pixel-plot height H',xticks=heights)
    ax.grid(axis='y',alpha=.17)
axs[0].legend(frameon=False)
save(fig,'03_cost_and_latency')

tasks=['oscillations','transients']
fig,axs=plt.subplots(1,2,figsize=(10.8,3.8))
positions=np.arange(2)
for j,(model,color) in enumerate([('1d',BLUE),('2d',ORANGE)]):
    values=[[r['test']['accuracy']*100 for r in R['training_runs']
             if r['task']==task and r['model']==model] for task in tasks]
    seconds=[[r['training_seconds'] for r in R['training_runs']
             if r['task']==task and r['model']==model] for task in tasks]
    at=positions+(j-.5)*.30
    for ax,data in zip(axs,[values,seconds]):
        means=[np.mean(v) for v in data]
        sd=[np.std(v,ddof=1) for v in data]
        ax.bar(at,means,width=.27,color=color,alpha=.8,label=model.upper()+' CNN',
               yerr=sd,capsize=4,error_kw={'elinewidth':1})
        for x,points in zip(at,data):
            ax.scatter(x+np.linspace(-.045,.045,len(points)),points,c='black',s=14,zorder=5)
axs[0].set(ylabel='Test accuracy (%)',ylim=(0,113),title='Fixed test set; three training seeds')
axs[1].set(ylabel='Training seconds (25 epochs)',title='Optimization loops; validation excluded')
for ax in axs:
    ax.set(xticks=positions,xticklabels=['Oscillations','Transients'])
    ax.grid(axis='y',alpha=.15)
axs[0].legend(frameon=False,loc='lower left')
save(fig,'04_accuracy_and_training')

fig,axs=plt.subplots(1,2,figsize=(10.6,3.6))
for ax,task in zip(axs,tasks):
    for model,color in [('1d',BLUE),('2d',ORANGE)]:
        runs=sorted([r for r in R['training_runs'] if r['task']==task and r['model']==model],key=lambda r:r['seed'])
        for i,run in enumerate(runs):
            ax.plot([v['epoch'] for v in run['history']],
                    [v['validation_accuracy']*100 for v in run['history']],
                    color=color,alpha=.75,lw=1.3,ls=['-','--',':'][i],
                    label=f'{model.upper()}, seed {run["seed"]}')
    ax.set(title=task.capitalize(),xlabel='Epoch',ylabel='Validation accuracy (%)',ylim=(45,103))
    ax.grid(axis='y',alpha=.15)
handles,labels=axs[1].get_legend_handles_labels()
fig.legend(handles,labels,frameon=False,fontsize=8,loc='outside lower center',ncol=3)
save(fig,'05_validation_curves')

tables={}
tables['RESOURCE_TABLE']='\n'.join([
    '| Input and model | Trainable parameters | MACs / series | Float32 input bytes |',
    '| --- | ---: | ---: | ---: |',
    *[f'| {"1D, N = 128" if b["model"]=="1d" else "2D, H = "+str(b["height"])+", W = 128"} | '
      f'{b["description"]["parameters"]:,} | {b["description"]["macs"]:,} | {b["description"]["input_bytes"]:,} |'
      for b in bench]])
tables['LATENCY_TABLE']='\n'.join([
    '| Model | Batch-1 median (ms) | Batch-1 IQR width (ms) | Batch-64 median / 64 (ms per series) |',
    '| --- | ---: | ---: | ---: |',
    *[f'| {"1D" if b["model"]=="1d" else "2D, H = "+str(b["height"])} | '
      f'{b["batch1"]["median_ms"]:.4f} | {b["batch1"]["iqr_ms"]:.4f} | '
      f'{b["batch64"]["amortized_ms_per_series"]:.4f} |' for b in bench]])
lines=['| Task | Model | Test accuracy, mean ± SD | Macro-F1, mean ± SD | Training seconds, mean ± SD |',
       '| --- | --- | ---: | ---: | ---: |']
for task in tasks:
    for model in ['1d','2d']:
        runs=[r for r in R['training_runs'] if r['task']==task and r['model']==model]
        fields=[]
        for key,scale,dec in [('accuracy',100,2),('macro_f1',1,3),('training_seconds',1,3)]:
            values=[(r['test'][key] if key!='training_seconds' else r[key])*scale for r in runs]
            fields.append(f'{np.mean(values):.{dec}f} ± {np.std(values,ddof=1):.{dec}f}'+('%' if key=='accuracy' else ''))
        lines.append(f'| {task.capitalize()} | {model.upper()} | '+' | '.join(fields)+' |')
tables['RESULTS_TABLE']='\n'.join(lines)
checks=R['exact_checks']
tables['EXACT_TABLE']='\n'.join(['| Numerical check | Maximum absolute difference |','| --- | ---: |',
    f'| Decoded samples versus quantized samples | {checks["max_reconstruction_error"]:.1e} |',
    f'| Logits of 1D model versus exact 2D simulation | {checks["max_logit_error"]:.1e} |',
    f'| Corresponding parameter gradients | {checks["max_parameter_gradient_error"]:.1e} |'])
tables['MAC_RATIO']=f'{next(b for b in images if b["height"]==32)["description"]["conv_macs"]/baseline["description"]["conv_macs"]:.2f}'
tables['LATENCY_RATIO']=f'{next(b for b in images if b["height"]==32)["batch1"]["median_ms"]/baseline["batch1"]["median_ms"]:.2f}'
tables['CPU']=R['environment']['cpu_model']
tables['PREPROCESS_QUANT_MS']=f'{next(p for p in R["preprocessing"] if p["task"]=="oscillations" and p["split"]=="train")["quantize_ms"]:.3f}'
tables['PREPROCESS_IMAGE_MS']=f'{next(p for p in R["preprocessing"] if p["task"]=="oscillations" and p["split"]=="train")["additional_image_allocation_ms"]:.3f}'
(ROOT/'results/article_values.json').write_text(json.dumps(tables,indent=2))
print('Created five original figures in PNG and SVG; tables derived from results.json')
