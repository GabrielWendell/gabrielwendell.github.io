// Optional final rendering step: embed MathJax SVG output for offline reading.
// npm install; node render_math.cjs
const fs = require('fs');
const path = require('path');
const root = process.env.MATHJAX_MODULE_ROOT || path.join(__dirname, 'node_modules');
const mj = name => require(path.join(root, 'mathjax-full/js', name));
const {mathjax} = mj('mathjax.js');
const {TeX} = mj('input/tex.js');
const {SVG} = mj('output/svg.js');
const {liteAdaptor} = mj('adaptors/liteAdaptor.js');
const {RegisterHTMLHandler} = mj('handlers/html.js');
const {AllPackages} = mj('input/tex/AllPackages.js');

const adaptor = liteAdaptor();
RegisterHTMLHandler(adaptor);
const errors = [];
const input = new TeX({packages:AllPackages.filter(x=>!['autoload','require'].includes(x)),
  formatError:(jax,error)=>{errors.push(error.message); return jax.formatError(error);}});
const output = new SVG({fontCache:'local'});
const document = mathjax.document('', {InputJax:input, OutputJax:output});
const filename = process.argv[2] || path.join(__dirname,'cnn_1d_vs_2d_time_series.html');
let page = fs.readFileSync(filename,'utf8');
if (page.includes('data-math-pretypeset="true"')) throw new Error('HTML already pretypeset; run build_post.py first');
let count = 0;
const decode = s => s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&')
  .replace(/&quot;/g,'"').replace(/&#x27;/g,"'");
page = page.replace(/(<article class="section">)([\s\S]*?)(<\/article>)/,
  (_,open,body,close) => open + body.replace(/\$\$[\s\S]+?\$\$|(?<!\$)\$[^\n$]+?\$(?!\$)/g, token => {
    const display = token.startsWith('$$');
    const tex = decode(token.slice(display?2:1, display?-2:-1));
    const node = document.convert(tex,{display});
    adaptor.setAttribute(node,'aria-label',tex);
    count++;
    return adaptor.outerHTML(node);
  }) + close);
if (errors.length || count===0) throw new Error(JSON.stringify({count,errors}));
page = page.replace(/<script>[\s\S]*?<\/script>/g,'')
  .replace(/<script defer src="https:\/\/cdn\.jsdelivr\.net\/npm\/mathjax@3\/es5\/tex-mml-chtml\.js"><\/script>/,'');
page = page.replace('</head>',adaptor.outerHTML(output.styleSheet(document))+'\n</head>');
page = page.replace('<html lang="en">','<html lang="en" data-math-pretypeset="true">');
fs.writeFileSync(filename,page);
console.log(JSON.stringify({mathjax:'3.2.2',node:process.version,expressions:count,tex_errors:errors,
  external_scripts_remaining:(page.match(/<script/g)||[]).length,html_bytes:Buffer.byteLength(page)}));
