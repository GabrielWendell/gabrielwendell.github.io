# 1D versus 2D CNNs: blog draft and reproducible examples

Read `cnn_1d_vs_2d_time_series.html` in a browser for the complete illustrated post. The delivered HTML embeds all five vector figures, the stylesheet, and equations pretypeset as SVG with MathJax 3.2.2. It can be read offline without fetching scripts, fonts, or images.

`cnn_1d_vs_2d_time_series.md` is the editable, fully populated Markdown version. Keep its `assets` directory beside it. `post_source.md` is the rendering source: its `@@...@@` tokens are filled from the recorded experiment results when `build_post.py` runs.

This is a standalone draft, adapted to the colors, typography, navigation conventions, and MathJax use of the supplied blog template. It does not change an existing page or publish anything. To integrate it later, place the HTML in your website's `blog/` directory and add a link from the existing blog index. The figures and CSS in the HTML are embedded, so copying that one file is sufficient; parent-relative navigation then points to the existing website pages.

## Reproduce

Tested environment: Linux x86_64, Python 3.12.14, PyTorch 2.5.1+cpu, NumPy 2.3.5, scikit-learn 1.8.0, Matplotlib 3.10.8, Markdown 3.11.3. The numerical experiment uses two CPU compute threads and one interop thread; it does not use a GPU. The server CPU model and other execution details are recorded in `results/results.json`. They do not imply exclusive use of the physical processor.

Create an isolated Python environment, activate it, and run:

```bash
python -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python experiments.py --output results --epochs 25 --threads 2 --seeds 42 43 44
python build_figures.py
python build_post.py
```

The Python-only HTML build renders equations through a MathJax CDN when opened online. To embed the equations for fully offline reading, as in the delivered HTML, use the optional Node step after `build_post.py`:

```bash
npm install --ignore-scripts --no-audit --no-fund
node render_math.cjs
```

This additional rendering step does not run or alter the numerical experiments. Edit the Markdown source and regenerate the HTML before running it again. Browser rendering could not be launched in this execution environment; document structure, all TeX expressions, and the original scientific figures were checked separately.

The CPU-wheel command targets the Linux/Windows CPU installation used here. On another platform, install a supported CPU PyTorch build first and record any version change. Exact timings and training trajectories are not promised across platforms or versions.

Running `experiments.py` replaces outputs in the selected directory. `build_figures.py` and `build_post.py` read the package's default `results/` directory; copy an alternative run there, or change their input paths, to render a different run. The original numeric values are preserved in the delivered archive. No dataset download is needed.

## Experiment scope

- Two independent synthetic tasks: low/high-frequency oscillations and single/double transients.
- Per task: 512 training, 128 validation, and 512 test series, each of length 128. Class counts are balanced within each split.
- Both main classifiers receive identical 32-level amplitude information on the fixed range [-2, 2). The image has shape 32 × 128, with one illuminated pixel per column. This is a controlled pixel plot, not a screenshot of a connected Matplotlib line.
- CNN channels: 8, 16, 24; kernels: width 5 in 1D, height 3 × width 5 in 2D. Pooling halves all spatial dimensions. Global average pooling and a two-class linear head follow.
- Adam, learning rate 0.003, batch size 64, 25 epochs. The best validation cross-entropy checkpoint is tested once for each fixed run. All selected checkpoints in this run happen to be epoch 25.
- Three training seeds on the same split quantify a small amount of optimization variability, not sampling uncertainty across new datasets. There is no hyperparameter tuning, transfer learning, or claim of a universal architectural ranking.
- Training time excludes validation and encoding. Inference times exclude encoding and use warm-up plus blocked autorange. The results also retain total training-plus-selection time and preprocessing measurements.
- Resource counts are dense convolution/linear MACs, parameters, and tensor sizes. They are not measured peak RAM or universal runtime lower bounds.

## Files

| File or directory | Purpose |
| --- | --- |
| `cnn_1d_vs_2d_time_series.html` | Complete single-file illustrated draft |
| `cnn_1d_vs_2d_time_series.md` | Filled Markdown draft |
| `post_source.md` | Editable Markdown template with result substitutions |
| `experiments.py` | Generators, both CNNs, exact simulation, timing, and training |
| `build_figures.py` | Regenerates the five PNG/SVG figures and numerical tables |
| `build_post.py` | Regenerates the populated Markdown and self-contained HTML |
| `render_math.cjs`, `package.json` | Optional MathJax SVG pretypesetting for an offline HTML copy |
| `requirements.txt` | Tested direct dependencies |
| `results/results.json` | Full configuration, environment, dataset hashes, timing, learning curves, and per-seed scores |
| `results/exact_checks.json` | Decoder/logit/gradient checks and exact collision example |
| `results/training_results.csv` | Flat per-seed numerical results |
| `results/predictions_*.npz` | Test labels and predicted classes for every run |
| `results/article_values.json` | Tables and numbers generated directly from results |
| `assets/` | Original scientific figures in PNG and SVG |
| `SHA256SUMS.txt` | File-integrity inventory for the delivered package |

The article distinguishes established facts from its own elementary derivations, exact toy counterexamples, and measured results. Its reference list links to primary papers and official documentation.
