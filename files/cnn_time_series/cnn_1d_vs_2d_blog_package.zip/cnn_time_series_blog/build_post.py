"""Render the editable draft, measured tables, and self-contained HTML post."""
from __future__ import annotations

import html
import json
import math
import re
from pathlib import Path

import markdown

ROOT=Path(__file__).parent
values=json.loads((ROOT/'results/article_values.json').read_text())
source=(ROOT/'post_source.md').read_text()
for key,value in values.items():
    source=source.replace('@@'+key+'@@',str(value))
if re.search(r'@@[A-Z_]+@@',source):
    raise ValueError('Unresolved draft substitution')
target=ROOT/'cnn_1d_vs_2d_time_series.md'
target.write_text(source)
title=source.splitlines()[0][2:]
body=re.sub(r'\A# [^\n]+\n\n\*[^\n]+\*\n\n\*\*Draft[^\n]+\*\*\n\n','',source)

# Preserve TeX delimiters, backslashes, and underscores across Markdown parsing.
math_items=[]
def hide_math(match):
    index=len(math_items)
    math_items.append(match.group())
    return f'MATHPLACEHOLDER{index:04d}END'
body=re.sub(r'\$\$[\s\S]+?\$\$|(?<!\$)\$[^\n$]+?\$(?!\$)',hide_math,body)
parser=markdown.Markdown(extensions=['tables','fenced_code','toc'],
                         extension_configs={'toc':{'toc_depth':'2-2','permalink':False}})
rendered=parser.convert(body)
for index,value in enumerate(math_items):
    token=f'MATHPLACEHOLDER{index:04d}END'
    safe=html.escape(value,quote=False)
    if value.startswith('$$'):
        rendered=rendered.replace('<p>'+token+'</p>','<div class="equation">'+safe+'</div>')
    rendered=rendered.replace(token,safe)

def embed_figure(match):
    filename=match.group(2)
    svg=(ROOT/filename).read_text()
    svg=svg[svg.index('<svg'):]
    # Multiple inline Matplotlib SVGs otherwise reuse group IDs such as axes_1.
    prefix='fig_'+Path(filename).stem+'__'
    for identifier in sorted(set(re.findall(r'\bid="([^"]+)"',svg)),key=len,reverse=True):
        replacement=prefix+identifier
        svg=svg.replace('id="'+identifier+'"','id="'+replacement+'"')
        svg=svg.replace('url(#'+identifier+')','url(#'+replacement+')')
        svg=svg.replace('href="#'+identifier+'"','href="#'+replacement+'"')
    alt=html.unescape(match.group(1))
    svg=svg.replace('<svg ','<svg role="img" aria-label="'+html.escape(alt,quote=True)+'" ',1)
    return '<figure class="research-figure">'+svg+'</figure>'
rendered=re.sub(r'<p><img alt="([^"]*)" src="(assets/[^"]+\.svg)"\s*/?></p>',embed_figure,rendered)
if '<img ' in rendered:
    raise ValueError('Unembedded figure remains')
rendered=re.sub(r'(<table>[\s\S]*?</table>)',r'<div class="table-scroll">\1</div>',rendered)
word_count=len(re.findall(r'\b[\w-]+\b',source))
minutes=math.ceil(word_count/220)

css='''
:root {--bg:#070e1a;--card:#0d1727;--accent:#5ac8fa;--text:#e6edf7;--muted:#b3bfd3;--border:#29374e;}
* {box-sizing:border-box} html {scroll-behavior:smooth} body {margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;line-height:1.78}
a {color:var(--accent);text-underline-offset:3px} a:hover {color:#b5e6ff} .container {max-width:1040px;margin:auto;padding:0 24px}
.site-header {border-bottom:1px solid var(--border);background:#0b1422} .nav-container {display:flex;align-items:center;justify-content:space-between;gap:24px;padding:18px 0}
.brand {font-size:1.05rem;font-weight:650;color:var(--text);text-decoration:none;white-space:nowrap}.site-nav {display:flex;gap:18px;font-size:.85rem}.site-nav a {text-decoration:none;color:var(--muted)}.site-nav .active {color:var(--accent)}
main {max-width:920px;margin:auto;padding:42px 24px 70px}.page-kicker {color:var(--accent);font-size:.76rem;font-weight:650;letter-spacing:.14em;text-transform:uppercase;margin:0 0 10px}
h1 {font-size:clamp(2rem,4.5vw,3rem);line-height:1.18;letter-spacing:-.035em;margin:0 0 18px;max-width:850px}.page-subtitle {color:var(--muted);font-size:1.14rem;margin:0 0 12px}.meta {color:var(--muted);font-size:.82rem;margin:0 0 28px}
.toc {border:1px solid var(--border);border-radius:12px;background:var(--card);padding:16px 22px;margin:25px 0 32px}.toc summary {font-weight:600;cursor:pointer}.toc ul {margin:8px 0 0;padding-left:20px;columns:2;column-gap:32px;font-size:.86rem}.toc li {margin:4px 0;break-inside:avoid}
article p {margin:0 0 1.05rem} h2 {font-size:1.45rem;line-height:1.35;margin:2.7rem 0 1rem;letter-spacing:-.02em;scroll-margin-top:24px}h3 {font-size:1.1rem;margin:1.9rem 0 .7rem} strong {font-weight:650} em {color:var(--muted)}
.equation {padding:6px 0;overflow-x:auto;overflow-y:hidden;margin:20px 0}mjx-container {overflow-x:auto;overflow-y:hidden;max-width:100%}
.table-scroll {overflow-x:auto;margin:22px 0;border:1px solid var(--border);border-radius:10px}table {border-collapse:collapse;width:100%;font-size:.85rem;line-height:1.55}th,td {padding:11px 13px;border-bottom:1px solid var(--border);vertical-align:top} th {background:#152139;text-align:left;color:#edf5ff}tr:last-child td {border-bottom:0}tbody tr:nth-child(even) {background:#0c1625}
.research-figure {margin:28px 0 14px;padding:8px;background:white;border:1px solid #d7e0ea;border-radius:10px;overflow:hidden}.research-figure svg {display:block;width:100%;height:auto}.research-figure+p {font-size:.85rem;line-height:1.65;color:var(--muted)}
code {font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:.88em}p code {background:#16243a;padding:.1em .3em;border-radius:4px}pre {padding:20px;background:#030914;border:1px solid var(--border);border-radius:10px;overflow-x:auto;line-height:1.65;margin:24px 0}pre code {font-size:.81rem}
ol,ul {padding-left:22px}li+li {margin-top:9px}#references~ol {font-size:.87rem;line-height:1.65}.site-footer {border-top:1px solid var(--border);color:var(--muted);padding:24px;font-size:.8rem;text-align:center}
@media(max-width:650px){.site-nav a:not(.active){display:none}main {padding:28px 16px 48px}.container {padding:0 16px}.toc ul {columns:1}table {font-size:.77rem}th,td {padding:9px 10px}.research-figure {padding:2px;border-radius:7px}h2 {font-size:1.28rem}}
@media print {body {background:white;color:#17202b;font-size:10pt}.site-header,.toc,.site-footer {display:none}main {max-width:none;padding:0}a {color:#176b9a}.page-subtitle,.meta,em {color:#4d5a6b}table,th,td {border-color:#cbd3de}th,tbody tr:nth-child(even) {background:#edf2f6;color:#17202b}.research-figure,pre {break-inside:avoid}pre {background:#f1f4f8;color:#17202b}h2 {break-after:avoid}.table-scroll {overflow:visible}.equation {overflow:visible}}
'''
script=r'''
window.MathJax={tex:{inlineMath:[['$','$'],['\\(','\\)']],displayMath:[['$$','$$'],['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};
'''
page='''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>'''+html.escape(title)+''' – Gabriel Wendell – Blog</title>
<meta name="description" content="Mathematical bounds and reproducible CPU experiments comparing numerical time-series inputs and pixel plots for 1D and 2D CNNs.">
<style>'''+css+'''</style><script>'''+script+'''</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
</head><body class="blog-post"><header class="site-header"><div class="container"><div class="nav-container">
<a class="brand" href="../index.html">Gabriel Wendell</a><nav class="site-nav" aria-label="Main navigation">
<a href="../research.html">Research</a><a href="../publications.html">Publications</a><a href="../software.html">Software</a><a class="active" href="../blog.html">Blog</a>
</nav></div></div></header><main><header class="page-header"><p class="page-kicker">Research notes · Machine learning</p>
<h1>'''+html.escape(title)+'''</h1><p class="page-subtitle">Information, computational bounds, and a controlled numerical experiment</p>
<p class="meta">Draft for Gabriel Wendell · November 21, 2026 · Approximately '''+str(minutes)+''' minutes · time-series · cnn · numerical-experiments</p></header>
<details class="toc"><summary>Contents</summary>'''+parser.toc+'''</details><article class="section">'''+rendered+'''</article>
<p style="margin-top:40px"><a href="../blog.html">← Back to the blog</a></p></main>
<footer class="site-footer">Gabriel Wendell Celestino Rocha · Blog draft · Reproducible numerical examples accompany the article.</footer></body></html>'''
(ROOT/'cnn_1d_vs_2d_time_series.html').write_text(page)
print(json.dumps({'markdown':str(target),'html':str(ROOT/'cnn_1d_vs_2d_time_series.html'),
                  'word_count_including_tables_and_math':word_count,'embedded_figures':page.count('class="research-figure"'),
                  'display_equations':rendered.count('class="equation"')}))
