# 1D versus 2D CNNs for Time-Series Classification

*Information, computational bounds, and a controlled numerical experiment*

**Draft for Gabriel Wendell · November 21, 2026**

A light curve, an electrocardiogram, and a vibration signal can all be stored as an ordered sequence of measurements. They can also be drawn as images. This creates a tempting question: if a convolutional neural network can recognize patterns in an image, should we turn every time series into a picture before classifying it?

A 1D CNN slides filters along the numerical sequence. A 2D CNN slides filters across a raster representation of that sequence. Both can recognize curve morphology, but they encode different assumptions about which patterns should be easy to learn.

The useful comparison combines three things: what information reaches the classifier, how much computation the chosen architecture performs, and how well a trained model generalizes. We can prove statements about the first two and measure parts of the third. Keeping their logical roles clear prevents a fast implementation from being mistaken for an accuracy theorem.

The calculations below culminate in two synthetic classification experiments, an exact numerical equivalence check, and a rasterization counterexample. The complete Python code, raw results, and original figures accompany this draft.

## What does “more efficient” mean?

There are several reasonable objectives, and they need not favor the same model.

| Objective | Quantity to compare |
| --- | --- |
| Classification quality | Error, macro-F1, or another task-appropriate metric on unseen series |
| Statistical efficiency | Number of independent labeled series needed for a target error |
| Inference efficiency | Arithmetic, latency, throughput, and memory per prediction |
| Training efficiency | Total cost of reaching a target validation quality |
| Representation efficiency | Cost and fidelity of preprocessing, storage, and transfer |

In particular, equal epoch counts do not imply equal computation. Equal parameter counts do not imply equal arithmetic. Equal information in the inputs does not imply that two restricted CNNs can express the same decision rules.

This post studies ordinary dense convolutions on numerical samples and controlled pixel plots. A spectrogram, recurrence plot, or wavelet map is a different representation with a different geometric structure; conclusions about ordinary curve plots should not automatically be transferred to those encodings.

## One classification problem, two representations

Let $X=(X_1,\ldots,X_N)$ be a univariate series sampled on a common time grid, and let $Y$ be its class. Write

$$Z=T(X)$$

for the image produced by a fixed, label-independent renderer. All information used by the renderer, including timestamps if applicable, must be included in $X$ for this comparison.

Define the Bayes errors

$$R_X^*=\inf_f\Pr[f(X)\ne Y],\qquad R_Z^*=\inf_g\Pr[g(Z)\ne Y].$$

The infima range over all measurable classifiers, without restricting their architecture. Every image classifier can be evaluated from the original measurements by computing $g(T(X))$. Therefore,

$$\boxed{R_X^*\le R_Z^*.}$$

If a decoder $D$ recovers $X$ from its image, then $f(D(Z))$ gives the reverse construction, so $R_X^*=R_Z^*$. More generally, equality is ensured when the representation preserves the conditional class probabilities. These are statistical statements about lossless transformations, rather than claims about training a particular CNN [1].

An associated information-theoretic bound, with information measured in nats, is

$$0\le R_Z^*-R_X^*\le\sqrt{\frac{I(Y;X\mid Z)}{2}}.$$

Small loss of class information bounds the increase in optimal classification error [1]. Evaluating that information loss from finite high-dimensional data is itself difficult.

An image can still help a finite model. It rearranges the problem into geometric features that may fit that model's inductive bias. Empirically, ordinary line-plot CNNs have been competitive on some time-series datasets: Rodrigues and collaborators investigated this directly [2]. Such results motivate experiments; they do not establish a universal ordering of 1D and 2D architectures.

## A pixel plot that is exactly reversible

To compare the networks without changing the information available to them, first quantize each measured amplitude using the same fixed range $[a,b)$ and $H$ uniform cells. Define

$$\Delta=\frac{b-a}{H},\qquad r_t=\left\lfloor\frac{X_t-a}{\Delta}\right\rfloor,\qquad Q_H(X)_t=a+(r_t+\tfrac12)\Delta.$$

Assume the observations are within range; otherwise clipping introduces an additional error. Construct an $H\times N$ image with one illuminated pixel in each column:

$$Z_{h,t}=\mathbf 1\{r_t=h\},\qquad h=0,\ldots,H-1.$$

The decoder is explicit:

$$D(Z)_t=\sum_{h=0}^{H-1}\left[a+(h+\tfrac12)\Delta\right]Z_{h,t}=Q_H(X)_t.$$

Thus the quantized numerical sequence and its pixel plot are information-equivalent. Quantization may discard information relative to the original measurements, but it does so **equally for both CNN inputs**. One time column per observation avoids temporal compression, and a fixed amplitude scale avoids silently removing mean level or variability amplitude.

![A numerical sequence and its reversible pixel plot for oscillations and transients.](assets/01_representations.svg)

*Figure 1. The controlled representation used below. The 1D model receives the blue quantized samples. The 2D model receives exactly their pixel encoding. These images contain no axes, labels, color coding, connecting line segments, or other metadata.*

This construction is deliberately simpler than a plotting-library screenshot. It lets us isolate information equivalence before studying the effects of line thickness, resizing, antialiasing, and per-plot scaling.

## An exact 2D implementation of a 1D CNN

There is also a useful equivalence at the network level. Take a conventional 1D CNN $f_\theta$ built from temporal convolutions, pointwise activations, pooling, and a classification head.

The pixel decoder can be implemented by a fixed 2D convolution with an $H\times1$ kernel. It collapses the image height to one. Each subsequent 1D convolution with kernel width $k$ can then be implemented as a $1\times k$ convolution with the same weights; temporal pooling becomes $1\times s$ pooling.

The resulting image network $g_\theta$ satisfies

$$\boxed{g_\theta(T(X))=f_\theta(Q_H(X))\quad\text{for all }X,\theta.}$$

The equality holds in exact arithmetic. Predictions and training objectives coincide, as do corresponding parameter gradients wherever the derivatives are defined, with matching conventions at nondifferentiable activations. The fixed decoder adds no trainable parameters.

With a straightforward dense decoder, the additional arithmetic is $\Theta(NH)$. Explicitly writing the dense image also requires $\Omega(NH)$ scalar writes, compared with $N$ scalar entries for the numerical input at the same tensor precision. Sparse encodings or eliminating the encoding–decoding pair can change these costs.

This proves that a 2D implementation can simulate the 1D classifier. It does not say that every 2D model must pay this decoding overhead, or that a model retaining a nontrivial image height has the same hypothesis class.

The accompanying code compares the decoder, logits, and gradients for a random model and a batch of 16 series. The executed float32 check produced:

| Numerical check | Maximum absolute difference |
| --- | ---: |
| Decoded samples versus quantized samples | 0.0e+00 |
| Logits of 1D model versus exact 2D simulation | 0.0e+00 |
| Corresponding parameter gradients | 0.0e+00 |

All predicted labels agreed. Zero difference in this execution is a numerical observation; equivalent implementations can differ by floating-point roundoff on other backends.

## Counting arithmetic, parameters, and activations

Now consider architectures that retain a genuine two-dimensional feature map. For a standard dense convolution, excluding bias additions, the multiply–accumulate counts per series are

$$C_{1,\ell}=N_\ell k_\ell c_{\ell-1}c_\ell,$$

$$C_{2,\ell}=H_\ell W_\ell q_\ell k_\ell c_{\ell-1}c_\ell.$$

Here $N_\ell$ is the 1D output length, $H_\ell\times W_\ell$ the 2D output shape, $k_\ell$ the temporal kernel width, $q_\ell$ the vertical kernel height, and $c_\ell$ the output channel count. The formulas follow by counting the products contributing to each convolution output [3]. One MAC is one multiply–accumulate; converting MACs to FLOPs requires stating a convention, often approximately two FLOPs per MAC.

If corresponding layers share channel counts, temporal widths, and temporal output lengths, so $W_\ell=N_\ell$, then

$$C_{2,\ell}=H_\ell q_\ell C_{1,\ell}.$$

Summing convolutional layers gives a weighted average:

$$\frac{C_{2,\mathrm{conv}}}{C_{1,\mathrm{conv}}}=\frac{\sum_\ell H_\ell q_\ell C_{1,\ell}}{\sum_\ell C_{1,\ell}},$$

and therefore the bounds

$$\boxed{\min_\ell(H_\ell q_\ell)\le\frac{C_{2,\mathrm{conv}}}{C_{1,\mathrm{conv}}}\le\max_\ell(H_\ell q_\ell).}$$

These are arithmetic bounds for the specified dense layer evaluations, rather than lower bounds for all algorithms computing those functions. They exclude pooling, activations, and the head, whose costs can be counted separately.

Ignoring biases, the corresponding kernel parameter counts are $k_\ell c_{\ell-1}c_\ell$ and $q_\ell k_\ell c_{\ell-1}c_\ell$. Their ratio is $q_\ell$, while the output-activation counts have ratio $H_\ell$. The factor controlling computation is consequently different from the factor controlling parameter storage.

If $H_\ell$ and kernel heights are fixed constants, both constructions can have linear arithmetic growth with series length. The distinction may be a substantial constant factor rather than a different asymptotic order. If image width is held fixed while $N$ grows, temporal compression changes the comparison and must be analyzed as part of the representation.

## Resolution can impose a classification floor

Suppose two equally likely constant series have amplitudes just below and just above a threshold inside one quantization cell. Their original numerical values determine the labels perfectly, but their pixel plots are identical. No image classifier can distinguish them:

$$R_X^*=0,\qquad R_Z^*=\tfrac12.$$

The same floor applies to a numerical classifier if it receives those quantized values. The failure belongs to the encoding, rather than to convolution dimensionality.

![Two constant curves become identical after quantization into one amplitude cell.](assets/02_quantization_collision.svg)

*Figure 2. An exact two-point counterexample, also checked in the Python script. With $H=32$ and range $[-2,2)$, the class amplitudes are 0.05 and 0.075. Both map to the cell center 0.0625. The 50% error is an analytical Bayes floor for this distribution, not a measured CNN score.*

A regularity assumption permits a more useful resolution bound. For binary classification, let $\eta(x)=\Pr(Y=1\mid X=x)$ and assume it has a version on the amplitude domain satisfying

$$|\eta(x)-\eta(x')|\le L\|x-x'\|_\infty.$$

For unclipped cell-center quantization, $\|X-Q_H(X)\|_\infty\le\Delta/2$. Consider the hypothetical plug-in classifier $h_Q(X)=\mathbf1\{\eta(Q_H(X))\ge1/2\}$. Whenever it disagrees with the raw Bayes decision, $|\eta(X)-1/2|\le L\Delta/2$. Using the binary classification excess-risk identity gives

$$\begin{aligned}R(h_Q)-R_X^*&=\mathbb E\left[|2\eta(X)-1|\,\mathbf1\{h_Q(X)\ne h^*(X)\}\right]\\&\le L\Delta.\end{aligned}$$

Since the best classifier on the quantized representation is at least as good as this hypothetical one,

$$\boxed{0\le R_{Q_H(X)}^*-R_X^*\le\frac{L(b-a)}{H}.}$$

This elementary plug-in argument is related to the broader theory of classification under regularity and margin assumptions [4]. It is conditional on the stated Lipschitz property, whose constant is generally unknown. The sharp-threshold counterexample violates that property. If clipping occurs with probability $p_{\mathrm{out}}$, the corresponding argument adds at most $p_{\mathrm{out}}$ to this error bound; Gaussian noise does not have bounded support.

Increasing $H$ therefore decreases this particular upper bound while increasing dense image costs. It does not guarantee that a trained 2D CNN improves monotonically with resolution. The inequality describes quantization loss; finite-network approximation, estimation, and optimization introduce other errors.

## The numerical experiment

The experiments use two balanced binary tasks, each with $N=128$ samples per series.

**Oscillations.** The observations follow $X_t=A\sin(2\pi f t+\phi)+m+\epsilon_t$ on $t=0,1/N,\ldots,(N-1)/N$. Class 0 has $f\sim U[2,3]$ cycles per window; class 1 has $f\sim U[5,6]$. Independently, $A\sim U[0.6,1.2]$, $\phi\sim U[0,2\pi]$, $m\sim U[-0.2,0.2]$, and $\epsilon_t\sim\mathcal N(0,0.08^2)$.

**Transients.** Class 0 contains one Gaussian peak of width 0.06. Class 1 contains two peaks of width 0.025, displaced by $\pm0.055$ from a shared center. The center is uniform in $[0.3,0.7]$ and the signal amplitude in $[0.8,1.3]$. Both classes include a sinusoidal background of amplitude 0.1, a random offset in $[-0.15,0.15]$, and independent Gaussian noise of standard deviation 0.06. The script gives the full generator.

For each task, independent generation seeds produce 512 training, 128 validation, and 512 test series, balanced within each split. No generated observation exceeds $[-2,2)$; the script aborts rather than silently clipping if that condition fails. Both models receive the same 32-level quantization. The data splits are fixed across three training seeds: 42, 43, and 44.

Each network has three convolution–ReLU–max-pooling blocks with 8, 16, and 24 channels. The 1D kernels have width 5; the 2D kernels have shape $3\times5$. Pooling halves the temporal dimension in both models and the vertical dimension in the image model. Global average pooling feeds a two-class linear head. There is no pretraining, normalization layer, dropout, or hyperparameter search.

Both use Adam with learning rate 0.003, batch size 64, and 25 epochs. The checkpoint with minimum validation cross-entropy is evaluated once on the test split. Training configurations are run in a reproducibly shuffled order. The procedure deliberately matches channel counts and training updates, not parameter count or computational budget. It is a controlled illustration, not an architecture-selection contest.

## Arithmetic and measured latency

The counted model resources are:

| Input and model | Trainable parameters | MACs / series | Float32 input bytes |
| --- | ---: | ---: | ---: |
| 1D, N = 128 | 2,698 | 107,568 | 512 |
| 2D, H = 16, W = 128 | 7,898 | 1,966,128 | 8,192 |
| 2D, H = 32, W = 128 | 7,898 | 3,932,208 | 16,384 |
| 2D, H = 64, W = 128 | 7,898 | 7,864,368 | 32,768 |

MAC totals include the convolutional layers and linear head, but exclude pooling, ReLU, and preprocessing. Input bytes assume float32 tensors; they are not total process or peak training memory. The implementation records layer shapes, parameter bytes, and convolution-output tensor sizes separately.

For the $H=32$ image, the first convolution costs $32\times3=96$ times its matched 1D layer. After vertical pooling, the network's total convolutional ratio is 36.57. All three image heights share the same trainable parameter count because convolution weights are shared over positions and global average pooling removes the remaining spatial dimensions.

The actual CPU timings were obtained using Python 3.12.14, NumPy 2.3.5, PyTorch 2.5.1+cpu, float32 tensors, and two PyTorch compute threads on an AMD EPYC 9V45 96-Core Processor. This is a shared execution environment, not a dedicated workstation benchmark.

Inference runs in evaluation and inference modes. Eight explicit warm-up calls precede `torch.utils.benchmark.Timer.blocked_autorange`, with the thread count set explicitly and a minimum measurement duration of 0.4 seconds. The benchmark utility performs additional adaptive warm-up and repeated measurements [5]. Model initialization, preprocessing, training, and compilation are outside these timings; no graph compilation is enabled.

| Model | Batch-1 median (ms) | Batch-1 IQR width (ms) | Batch-64 median / 64 (ms per series) |
| --- | ---: | ---: | ---: |
| 1D | 0.0479 | 0.0031 | 0.0033 |
| 2D, H = 16 | 0.1169 | 0.0076 | 0.0514 |
| 2D, H = 32 | 0.1970 | 0.0034 | 0.1020 |
| 2D, H = 64 | 0.3351 | 0.0248 | 0.3161 |

IQR is the interquartile-range width of repeated timing measurements, not a statistical confidence interval for generalization. Batch-64 time divided by 64 measures amortized processing cost; it is not the latency experienced by a single request waiting for a batch to form.

![Dense convolution operation counts and measured CPU latency as image height changes.](assets/03_cost_and_latency.svg)

*Figure 3. Analytical convolution counts and measured inference medians. The 1D baseline is dashed. The image-model arithmetic grows with height, while the timing ratios depend on batching and implementation.*

At $H=32$, the batch-1 latency ratio is 4.11, much smaller than the convolutional MAC ratio. Fixed overhead, memory access, threading, and backend kernels all affect elapsed time. An arithmetic bound is not a hardware-independent prediction of milliseconds.

Preprocessing is inexpensive in this particular in-memory encoder but is still measurable. For the 512 oscillation training curves, median quantization took 0.081 ms, and allocating and filling the additional image tensors took 0.271 ms. These medians come from nine calls. They exclude disk I/O, transfer to an accelerator, and any plotting-library screenshot rendering.

## What the classifiers learned

| Task | Model | Test accuracy, mean ± SD | Macro-F1, mean ± SD | Training seconds, mean ± SD |
| --- | --- | ---: | ---: | ---: |
| Oscillations | 1D | 100.00 ± 0.00% | 1.000 ± 0.000 | 0.290 ± 0.007 |
| Oscillations | 2D | 100.00 ± 0.00% | 1.000 ± 0.000 | 3.228 ± 0.081 |
| Transients | 1D | 100.00 ± 0.00% | 1.000 ± 0.000 | 0.303 ± 0.014 |
| Transients | 2D | 80.53 ± 26.77% | 0.750 ± 0.363 | 2.923 ± 0.086 |

The dispersions are sample standard deviations across three training seeds on one fixed data split. They are not confidence intervals over new datasets. Training seconds cover all 25 optimization epochs, including batch indexing and gradient updates, but exclude validation, initialization, and representation construction. Training-plus-validation times are also retained in the raw JSON and CSV.

![Test accuracy and training time for the two tasks, with individual seed results.](assets/04_accuracy_and_training.svg)

*Figure 4. Bars show means, error bars show sample standard deviations, and black points show individual training seeds. The synthetic tasks are intentionally small. Zero observed test errors do not establish zero population error.*

Both models reached perfect observed test accuracy on oscillations under this recipe. On transients, all three 1D runs reached 100%, while the 2D runs reached 100%, 91.60%, and 50%. The validation histories show substantial optimization variability in the image model:

![Validation accuracy across the 25 training epochs for every seed.](assets/05_validation_curves.svg)

*Figure 5. Individual validation trajectories. The chance-level image run remains near 50% through the allocated training budget. Other image runs learn the same task, demonstrating why a failed optimization run cannot establish an information-theoretic limitation.*

The selected checkpoint was epoch 25 in every run. The experiment shows that the numerical architecture was faster and more reliable under these particular settings. It does not show that every 2D CNN is worse on transients, or that the learning rate and width choices were equally suitable for both architectures.

The timing and accuracy comparisons answer different questions. A checkpoint selected from 25 equal-budget epochs describes one training procedure. A comparison of the cheapest models reaching the same accuracy would need an additional search over architectures and optimization settings, with the search costs recorded.

## Accuracy at a computational budget

For fixed model families and a stated cost measure, one useful theoretical quantity is

$$\mathcal C_j(\varepsilon)=\inf_{f\in\mathcal H_j:\,R(f)\le\varepsilon}\left[C_{\mathrm{pre},j}+C_{\mathrm{infer}}(f)\right],\qquad j\in\{1,2\}.$$

An empty feasible set has value $+\infty$. This definition concerns inference by an available classifier. Training data, optimization, and architecture-search budgets require separate constraints if the goal is end-to-end learning efficiency.

A comparison of $\mathcal C_1$ and $\mathcal C_2$ requires knowledge of the classification problem, not only kernel dimensions. Proving a strict separation requires a constructive upper bound for one family and a lower bound for the other. Comparing two upper bounds does not prove optimality.

For a fitted classifier frozen before inspecting an independent test set, Hoeffding's inequality gives a simple computable certificate. For $M$ such classifiers and $n_{\mathrm{test}}$ independent test observations,

$$\left|R(\widehat f_j)-\widehat R_{\mathrm{test},j}\right|\le\sqrt{\frac{\ln(2M/\delta)}{2n_{\mathrm{test}}}}$$

simultaneously with probability at least $1-\delta$. In the experiments above, sampling is independent conditional on the fixed class labels, and equal class counts target the equal-prior risk; the corresponding Hoeffding argument applies to those independent class-conditional errors. Multiple seeds share test objects, so their test errors should not be treated as additional independent test samples.

A confidence interval for a trained classifier still does not bound the optimal error of its entire architecture family. This is why benchmark outcomes and analytical lower bounds should be presented as different kinds of evidence.

## Reproducing and extending the comparison

The companion files contain `experiments.py`, `build_figures.py`, raw JSON and CSV results, per-seed predictions, and the original SVG and PNG figures. On a compatible Python environment, the CPU reproduction commands are:

```bash
python -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python experiments.py --epochs 25 --threads 2 --seeds 42 43 44
python build_figures.py
python build_post.py
```

The package records the tested dependency versions. Other hardware or library versions may change timings and floating-point training trajectories. The mathematical decoder identity and arithmetic counts do not depend on a particular runtime measurement.

The central encoder is short enough to inspect directly:

```python
step = (high - low) / height
codes = np.floor((x - low) / step).astype(np.int64)
quantized = low + (codes + 0.5) * step
image = np.zeros((len(x), 1, height, x.shape[-1]), np.float32)
image[np.arange(len(x))[:, None], 0, codes,
      np.arange(x.shape[-1])[None, :]] = 1.0
```

Here the inputs must already be within the fixed range. The full implementation validates the generated data and handles index bounds explicitly.

For a broader study, the next experiments would compare equal-parameter and equal-computation budgets, repeat independently generated datasets, and sweep learning rate, width, and image resolution using validation data. Pretrained image models would constitute an additional regime because external training data change the comparison. Strong temporal baselines such as InceptionTime should also be included before making a practical architecture recommendation [6].

Astronomical light curves add another requirement: preserving observation times, uncertainties, and missingness consistently. Feeding only flux values to a standard 1D CNN while a plot encodes irregular timestamps creates an information mismatch. Likewise, normalizing each curve independently can remove an amplitude or offset that the scientific classification depends on.

In this controlled experiment, numerical convolution avoids substantial image-processing work while retaining the same quantized observations. The general mathematical result is narrower: the specified dense architectures have calculable resource ratios, reversible encodings preserve optimal classification error, and lossy rendering can impose an irreducible floor. Whether a different image representation earns back its cost through a better learning bias remains a task-specific question that can be tested with the same discipline.

## References

1. Györfi, L., Linder, T., and Walk, H. (2023). *Lossless Transformations and Excess Risk Bounds in Statistical Inference*. Entropy 25, 1394. [Article and proofs](https://www.mdpi.com/1099-4300/25/10/1394).
2. Rodrigues, N. M., Batista, J. E., Trujillo, L., Duarte, B., Giacobini, M., Vanneschi, L., and Silva, S. (2021). *Plotting time: On the usage of CNNs for time series classification*. [arXiv:2102.04179](https://arxiv.org/abs/2102.04179).
3. PyTorch documentation. [Conv1d](https://docs.pytorch.org/docs/stable/generated/torch.nn.Conv1d.html) and [Conv2d](https://docs.pytorch.org/docs/stable/generated/torch.nn.Conv2d.html). These document the convolution definitions; the arithmetic counts in this post are derived by counting their dense evaluations.
4. Audibert, J.-Y., and Tsybakov, A. B. (2007). *Fast learning rates for plug-in classifiers*. Annals of Statistics 35, 608–633. [Author-hosted paper](https://imagine.enpc.fr/~audibert/AudTsy_AOS0231.pdf). The elementary quantization lemma above is derived explicitly here; no minimax rate from this paper is asserted for the numerical experiments.
5. PyTorch documentation. [Benchmark utilities](https://docs.pytorch.org/docs/stable/benchmark_utils.html) and [benchmarking tutorial](https://docs.pytorch.org/tutorials/recipes/recipes/benchmark.html).
6. Ismail Fawaz, H., and collaborators (2020). *InceptionTime: Finding AlexNet for Time Series Classification*. Data Mining and Knowledge Discovery 34, 1936–1962. [Paper](https://arxiv.org/abs/1909.04939).
